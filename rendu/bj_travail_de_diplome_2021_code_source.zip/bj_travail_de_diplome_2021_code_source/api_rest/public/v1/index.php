<!DOCTYPE html>
<html lang="fr">
<head>
    <title>api-rest-douceur-de-chien</title>
</head>
<body>
    <h1>api-rest-douceur-de-chien.boreljaquet.ch</h1><p>Cette API est en cours de développement.</p>
</body>
</html>