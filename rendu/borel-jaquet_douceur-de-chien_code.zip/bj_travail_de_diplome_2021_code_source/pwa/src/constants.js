/*
  constants.js
  
  File containing the constants of the application.

  Jonathan Borel-Jaquet - CFPT / T.IS-ES2 <jonathan.brljq@eduge.ch>
*/

export const CUSTOMER_CODE_ROLE = "1";
export const ADMIN_CODE_ROLE = "2";
