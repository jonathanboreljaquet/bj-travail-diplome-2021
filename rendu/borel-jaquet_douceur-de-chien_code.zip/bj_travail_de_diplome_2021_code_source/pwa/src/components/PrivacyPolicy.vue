<!--
  PrivacyPolicy.vue

  Component representing the privacy policies of the application.

  Jonathan Borel-Jaquet - CFPT / T.IS-ES2 <jonathan.brljq@eduge.ch>
-->

<template>
  <div class="content">
    <b-container>
      <b-row id="title" class="text-center">
        <b-col>
          <h1 class="font-weight-bold">Politique de condidentalité</h1>
        </b-col>
      </b-row>
      <b-row class="text-center">
        <b-col>
          <small
            ><p style="margin-bottom: 0px">
              Politique de confidentialité
            </p></small
          >
          <small><p>Dernière révision : 15/04/2021</p></small>
        </b-col>
      </b-row>
      <b-row>
        <b-col id="privacyPolicy">
          <small
            ><p>Introduction</p>
            <p class="text-justify">
              Nous nous soucions de la vie privée des utilisateurs de notre site
              Internet et/ou de notre espace mobile (le « Site » et l’« Espace
              mobile », respectivement) et nous nous engageons à protéger les
              informations que les utilisateurs partagent avec nous lorsqu’ils
              utilisent notre Site et/ou notre Espace mobile (collectivement,
              les « Propriétés numériques »), et nous nous engageons pleinement
              à protéger et à utiliser vos informations conformément à la loi
              applicable. Cette Politique de confidentialité décrit nos
              pratiques en matière de recueil, d'utilisation et de divulgation
              de vos informations par le biais de nos propriétés numériques (les
              « Services »), lorsque vous accédez aux Services depuis votre
              appareil. Avant d'accéder ou d'utiliser l'un de nos Services,
              veuillez lire attentivement cette Politique de confidentialité et
              vous assurer que vous comprenez parfaitement nos pratiques
              concernant vos informations. Si vous lisez et comprenez pleinement
              cette Politique de confidentialité, et que vous restez opposé(e) à
              nos pratiques, vous devez immédiatement et cesser toute
              utilisation de nos Propriétés numérique et de nos Services. En
              utilisant nos Services, vous acceptez les conditions de cette
              Politique de confidentialité et le fait de continuer à utiliser
              les Services constitue votre acceptation de cette Politique de
              confidentialité et de tout amendement à celle-ci. Dans la présente
              Politique de confidentialité, vous trouverez des explications sur
              les questions suivantes :
            </p>
            <ul>
              <li>Les informations que nous recueillons</li>
              <li>Comment nous recueillons les informations</li>
            </ul>
            <p>
              Les informations que nous recueillons<br />Vous trouverez
              ci-dessous les différents types d'informations que nous pouvons
              recueillir.
            </p>
            <ul>
              <li>
                Les informations non identifiées et non identifiables, qui
                peuvent être fournies par vous lors du processus
                d'enregistrement ou recueillies lorsque vous utilisez nos
                Services (les « Informations non personnelles »). Les
                informations non personnelles ne nous permettent pas
                d'identifier la personne auprès de qui elles ont été
                recueillies. Les Informations non personnelles que nous
                recueillons consistent principalement en des informations
                techniques et des informations d'utilisation agrégées.
              </li>
              <li>
                Les informations permettant de vous identifier individuellement,
                c’est-à-dire les informations qui vous identifient ou qui
                peuvent, moyennant un effort raisonnable, vous identifier (les «
                Informations personnelles »). Les Informations personnelles que
                nous recueillons par le biais de nos Services sont notamment le
                nom, l'adresse e-mail, l'adresse, le numéro de téléphone, ou
                d'autres informations demandées à chaque fois que nécessaire. Si
                nous combinons des Informations personnelles avec des
                Informations non personnelles, nous traiterons les informations
                combinées comme des Informations personnelles aussi longtemps
                longtemps qu'elles resteront combinées.
              </li>
            </ul>
            <p>
              Comment nous recueillons les informations<br />Vous trouverez
              ci-dessous les principales méthodes que nous utilisons pour
              recueillir des informations :
            </p>
            <ul>
              <li>
                Nous recueillons des informations lorsque vous utilisez les
                Services. Lorsque vous visitez nos Propriétés numériques ou que
                vous utilisez nos Services, nous pouvons recueillir, collecter
                et enregistrer ces utilisations, sessions et informations
                connexes.
              </li>
              <li>
                Nous recueillons les informations que vous nous fournissez
                volontairement. Par exemple, nous recueillons les informations
                que vous nous fournissez lorsque vous nous contactez directement
                par n'importe quel canal de communication (par exemple lorsque
                vous nous envoyez un e-mail contenant un commentaire ou un
                retour d'information).
              </li>
            </ul>
          </small>
        </b-col>
      </b-row>
    </b-container>
  </div>
</template>

<script>
export default {
  name: "PrivacyPolicy",
};
</script>

<style scoped>
#title {
  margin-top: 20px;
  color: #3ea3d8;
}
</style>
